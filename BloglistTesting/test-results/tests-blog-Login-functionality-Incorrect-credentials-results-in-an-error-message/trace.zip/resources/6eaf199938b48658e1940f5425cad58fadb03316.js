import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/RenderBlog.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f0094fdc"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/saiadiraju/Library/CloudStorage/GoogleDrive-saiadi4002@gmail.com/My Drive/Programming/AppDev/Full Stack Open/bloglist-frontend/src/components/RenderBlog.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=f0094fdc"; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"]; const useRef = __vite__cjsImport3_react["useRef"];
import Blog from "/src/components/Blog.jsx?t=1710794759149";
import blogService from "/src/services/blogs.js";
import NewBlog from "/src/components/NewBlog.jsx";
import VisibilityComponent from "/src/components/Visibility.jsx";
const RenderBlog = ({
  setUser,
  user
}) => {
  _s();
  const [blogs, setBlogs] = useState([]);
  const GlobalToggle = useRef();
  const likeBlog = (blog, user2) => {
    blogService.likeBlog(blog, user2);
  };
  const addBlog = async (title, author, url, user2, setMessage, selfToggle) => {
    try {
      await blogService.addBlog(title, author, url, user2);
      setMessage([`a new blog ${title} by ${author} added!`, "green"]), setTimeout(() => {
        setMessage(["null", "green"]);
        selfToggle();
      }, "5000");
    } catch {
      setMessage([`${title} by ${author} couldn't be added, please try again later`, "red"]), setTimeout(() => {
        setMessage(["null", "green"]);
      }, "5000");
      console.log(self);
    }
  };
  useEffect(() => {
    blogService.getAll().then((blogs2) => setBlogs(blogs2.sort((a, b) => b.likes - a.likes)));
  }, []);
  return /* @__PURE__ */ jsxDEV(Fragment, { children: /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV("p", { children: [
      `${String(user.name)} logged in`,
      /* @__PURE__ */ jsxDEV("button", { onClick: () => {
        setUser("");
        window.location.reload();
        window.localStorage.clear();
      }, children: "Log Out" }, void 0, false, {
        fileName: "/Users/saiadiraju/Library/CloudStorage/GoogleDrive-saiadi4002@gmail.com/My Drive/Programming/AppDev/Full Stack Open/bloglist-frontend/src/components/RenderBlog.jsx",
        lineNumber: 37,
        columnNumber: 54
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/saiadiraju/Library/CloudStorage/GoogleDrive-saiadi4002@gmail.com/My Drive/Programming/AppDev/Full Stack Open/bloglist-frontend/src/components/RenderBlog.jsx",
      lineNumber: 37,
      columnNumber: 17
    }, this),
    /* @__PURE__ */ jsxDEV(VisibilityComponent, { invisiblemessage: "new blog", visiblemessage: "cancel", ref: GlobalToggle, children: /* @__PURE__ */ jsxDEV(NewBlog, { user, selfToggle: GlobalToggle, addBlog }, void 0, false, {
      fileName: "/Users/saiadiraju/Library/CloudStorage/GoogleDrive-saiadi4002@gmail.com/My Drive/Programming/AppDev/Full Stack Open/bloglist-frontend/src/components/RenderBlog.jsx",
      lineNumber: 44,
      columnNumber: 21
    }, this) }, void 0, false, {
      fileName: "/Users/saiadiraju/Library/CloudStorage/GoogleDrive-saiadi4002@gmail.com/My Drive/Programming/AppDev/Full Stack Open/bloglist-frontend/src/components/RenderBlog.jsx",
      lineNumber: 43,
      columnNumber: 17
    }, this),
    blogs.map((blog) => /* @__PURE__ */ jsxDEV(Blog, { blog, user, setBlogList: setBlogs, blogList: blogs, like: likeBlog }, blog.id, false, {
      fileName: "/Users/saiadiraju/Library/CloudStorage/GoogleDrive-saiadi4002@gmail.com/My Drive/Programming/AppDev/Full Stack Open/bloglist-frontend/src/components/RenderBlog.jsx",
      lineNumber: 46,
      columnNumber: 36
    }, this))
  ] }, void 0, true, {
    fileName: "/Users/saiadiraju/Library/CloudStorage/GoogleDrive-saiadi4002@gmail.com/My Drive/Programming/AppDev/Full Stack Open/bloglist-frontend/src/components/RenderBlog.jsx",
    lineNumber: 36,
    columnNumber: 13
  }, this) }, void 0, false, {
    fileName: "/Users/saiadiraju/Library/CloudStorage/GoogleDrive-saiadi4002@gmail.com/My Drive/Programming/AppDev/Full Stack Open/bloglist-frontend/src/components/RenderBlog.jsx",
    lineNumber: 35,
    columnNumber: 10
  }, this);
};
_s(RenderBlog, "I+LBHe7LY42TJ/IaXkmIbV8f0/Q=");
_c = RenderBlog;
export default RenderBlog;
var _c;
$RefreshReg$(_c, "RenderBlog");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/saiadiraju/Library/CloudStorage/GoogleDrive-saiadi4002@gmail.com/My Drive/Programming/AppDev/Full Stack Open/bloglist-frontend/src/components/RenderBlog.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBbUNRLG1CQUU2QyxjQUY3Qzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFuQ1IsU0FBU0EsVUFBVUMsV0FBV0MsY0FBYztBQUM1QyxPQUFPQyxVQUFVO0FBQ2pCLE9BQU9DLGlCQUFpQjtBQUN4QixPQUFPQyxhQUFhO0FBQ3BCLE9BQU9DLHlCQUF5QjtBQUVoQyxNQUFNQyxhQUFhQSxDQUFDO0FBQUEsRUFBRUM7QUFBQUEsRUFBU0M7QUFBSyxNQUFNO0FBQUFDLEtBQUE7QUFDdEMsUUFBTSxDQUFDQyxPQUFPQyxRQUFRLElBQUlaLFNBQVMsRUFBRTtBQUNyQyxRQUFNYSxlQUFlWCxPQUFPO0FBQzVCLFFBQU1ZLFdBQVdBLENBQUNDLE1BQU1OLFVBQVM7QUFDN0JMLGdCQUFZVSxTQUFTQyxNQUFNTixLQUFJO0FBQUEsRUFDbkM7QUFDQSxRQUFNTyxVQUFVLE9BQU9DLE9BQU9DLFFBQVFDLEtBQUtWLE9BQU1XLFlBQVlDLGVBQWU7QUFDeEUsUUFBRztBQUNDLFlBQU1qQixZQUFZWSxRQUFRQyxPQUFPQyxRQUFRQyxLQUFLVixLQUFJO0FBQ2xEVyxpQkFBVyxDQUFFLGNBQWFILEtBQU0sT0FBTUMsTUFBTyxXQUFVLE9BQU8sQ0FBQyxHQUMvREksV0FBVyxNQUFNO0FBQ2JGLG1CQUFXLENBQUMsUUFBUSxPQUFPLENBQUM7QUFFNUJDLG1CQUFXO0FBQUEsTUFDZixHQUFHLE1BQU07QUFBQSxJQUNiLFFBQVE7QUFDSkQsaUJBQVcsQ0FBRSxHQUFFSCxLQUFNLE9BQU1DLE1BQU8sOENBQTZDLEtBQUssQ0FBQyxHQUNyRkksV0FBVyxNQUFNO0FBQ2JGLG1CQUFXLENBQUMsUUFBUSxPQUFPLENBQUM7QUFBQSxNQUNoQyxHQUFHLE1BQU07QUFDVEcsY0FBUUMsSUFBSUMsSUFBSTtBQUFBLElBQ3BCO0FBQUEsRUFDSjtBQUNBeEIsWUFBVSxNQUFNO0FBQ1pHLGdCQUFZc0IsT0FBTyxFQUFFQyxLQUFLaEIsWUFDdEJDLFNBQVNELE9BQU1pQixLQUFLLENBQUNDLEdBQUdDLE1BQU1BLEVBQUVDLFFBQVFGLEVBQUVFLEtBQUssQ0FBQyxDQUNwRDtBQUFBLEVBQ0osR0FBRyxFQUFFO0FBQ0wsU0FDSSxtQ0FDSSxpQ0FBQyxTQUNHO0FBQUEsMkJBQUMsT0FBSTtBQUFBLFNBQUVDLE9BQU92QixLQUFLd0IsSUFBSSxDQUFFO0FBQUEsTUFBWSx1QkFBQyxZQUFPLFNBQVMsTUFBTTtBQUN4RHpCLGdCQUFRLEVBQUU7QUFFVjBCLGVBQU9DLFNBQVNDLE9BQU87QUFDdkJGLGVBQU9HLGFBQWFDLE1BQU07QUFBQSxNQUM5QixHQUFHLHVCQUxrQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBSzNCO0FBQUEsU0FMVjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBS21CO0FBQUEsSUFDbkIsdUJBQUMsdUJBQW9CLGtCQUFpQixZQUFXLGdCQUFlLFVBQVMsS0FBS3pCLGNBQzFFLGlDQUFDLFdBQVEsTUFBWSxZQUFZQSxjQUFjLFdBQS9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBZ0UsS0FEcEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsSUFDQ0YsTUFBTTRCLElBQUl4QixVQUFRLHVCQUFDLFFBQW1CLE1BQVksTUFBWSxhQUFhSCxVQUFVLFVBQVVELE9BQU8sTUFBTUcsWUFBL0VDLEtBQUt5QixJQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQW1HLENBQUU7QUFBQSxPQVY1SDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBV0EsS0FaSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBYUE7QUFFUjtBQUFDOUIsR0E1Q0tILFlBQVU7QUFBQWtDLEtBQVZsQztBQThDTixlQUFlQTtBQUFVLElBQUFrQztBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJ1c2VFZmZlY3QiLCJ1c2VSZWYiLCJCbG9nIiwiYmxvZ1NlcnZpY2UiLCJOZXdCbG9nIiwiVmlzaWJpbGl0eUNvbXBvbmVudCIsIlJlbmRlckJsb2ciLCJzZXRVc2VyIiwidXNlciIsIl9zIiwiYmxvZ3MiLCJzZXRCbG9ncyIsIkdsb2JhbFRvZ2dsZSIsImxpa2VCbG9nIiwiYmxvZyIsImFkZEJsb2ciLCJ0aXRsZSIsImF1dGhvciIsInVybCIsInNldE1lc3NhZ2UiLCJzZWxmVG9nZ2xlIiwic2V0VGltZW91dCIsImNvbnNvbGUiLCJsb2ciLCJzZWxmIiwiZ2V0QWxsIiwidGhlbiIsInNvcnQiLCJhIiwiYiIsImxpa2VzIiwiU3RyaW5nIiwibmFtZSIsIndpbmRvdyIsImxvY2F0aW9uIiwicmVsb2FkIiwibG9jYWxTdG9yYWdlIiwiY2xlYXIiLCJtYXAiLCJpZCIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiUmVuZGVyQmxvZy5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUsIHVzZUVmZmVjdCwgdXNlUmVmIH0gZnJvbSAncmVhY3QnXG5pbXBvcnQgQmxvZyBmcm9tICcuLi9jb21wb25lbnRzL0Jsb2cnXG5pbXBvcnQgYmxvZ1NlcnZpY2UgZnJvbSAnLi4vc2VydmljZXMvYmxvZ3MnXG5pbXBvcnQgTmV3QmxvZyBmcm9tICcuL05ld0Jsb2cnXG5pbXBvcnQgVmlzaWJpbGl0eUNvbXBvbmVudCBmcm9tICcuL1Zpc2liaWxpdHknXG5cbmNvbnN0IFJlbmRlckJsb2cgPSAoeyBzZXRVc2VyLCB1c2VyIH0pID0+IHtcbiAgICBjb25zdCBbYmxvZ3MsIHNldEJsb2dzXSA9IHVzZVN0YXRlKFtdKVxuICAgIGNvbnN0IEdsb2JhbFRvZ2dsZSA9IHVzZVJlZigpXG4gICAgY29uc3QgbGlrZUJsb2cgPSAoYmxvZywgdXNlcikgPT4ge1xuICAgICAgICBibG9nU2VydmljZS5saWtlQmxvZyhibG9nLCB1c2VyKVxuICAgIH1cbiAgICBjb25zdCBhZGRCbG9nID0gYXN5bmMgKHRpdGxlLCBhdXRob3IsIHVybCwgdXNlciwgc2V0TWVzc2FnZSwgc2VsZlRvZ2dsZSkgPT4ge1xuICAgICAgICB0cnl7XG4gICAgICAgICAgICBhd2FpdCBibG9nU2VydmljZS5hZGRCbG9nKHRpdGxlLCBhdXRob3IsIHVybCwgdXNlcilcbiAgICAgICAgICAgIHNldE1lc3NhZ2UoW2BhIG5ldyBibG9nICR7dGl0bGV9IGJ5ICR7YXV0aG9yfSBhZGRlZCFgLCAnZ3JlZW4nXSksXG4gICAgICAgICAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgICAgICAgICBzZXRNZXNzYWdlKFsnbnVsbCcsICdncmVlbiddKVxuICAgICAgICAgICAgICAgIC8vIHVzZXMgcmVmZXJlbmNlZCBzZWxmIHRvZ2dsZSBmdW5jdGlvbiB0byBhdXRvbWF0aWNhbGx5IGhpZGUgdGhlIGZvcm0gYWZ0ZXIgYmxvZyBpcyBhZGRlZC5cbiAgICAgICAgICAgICAgICBzZWxmVG9nZ2xlKClcbiAgICAgICAgICAgIH0sICc1MDAwJylcbiAgICAgICAgfSBjYXRjaCB7XG4gICAgICAgICAgICBzZXRNZXNzYWdlKFtgJHt0aXRsZX0gYnkgJHthdXRob3J9IGNvdWxkbid0IGJlIGFkZGVkLCBwbGVhc2UgdHJ5IGFnYWluIGxhdGVyYCwgJ3JlZCddKSxcbiAgICAgICAgICAgIHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICAgICAgICAgIHNldE1lc3NhZ2UoWydudWxsJywgJ2dyZWVuJ10pXG4gICAgICAgICAgICB9LCAnNTAwMCcpXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhzZWxmKVxuICAgICAgICB9XG4gICAgfVxuICAgIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgICAgIGJsb2dTZXJ2aWNlLmdldEFsbCgpLnRoZW4oYmxvZ3MgPT5cbiAgICAgICAgICAgIHNldEJsb2dzKGJsb2dzLnNvcnQoKGEsIGIpID0+IGIubGlrZXMgLSBhLmxpa2VzKSlcbiAgICAgICAgKVxuICAgIH0sIFtdKVxuICAgIHJldHVybiAoXG4gICAgICAgIDw+XG4gICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgIDxwPntgJHtTdHJpbmcodXNlci5uYW1lKX0gbG9nZ2VkIGluYH08YnV0dG9uIG9uQ2xpY2s9eygpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgc2V0VXNlcignJylcbiAgICAgICAgICAgICAgICAgICAgLy8gcmVsb2FkcyB0aGUgd2luZG93IHRvIHJlcGVhdCB0aGUgdXNlciBjaGVja2luZyBwcm9jZXNzIGFuZCByZXR1cm4gdG8gYSBsb2dpbiBzY3JlZW5cbiAgICAgICAgICAgICAgICAgICAgd2luZG93LmxvY2F0aW9uLnJlbG9hZCgpXG4gICAgICAgICAgICAgICAgICAgIHdpbmRvdy5sb2NhbFN0b3JhZ2UuY2xlYXIoKVxuICAgICAgICAgICAgICAgIH19PkxvZyBPdXQ8L2J1dHRvbj48L3A+XG4gICAgICAgICAgICAgICAgPFZpc2liaWxpdHlDb21wb25lbnQgaW52aXNpYmxlbWVzc2FnZT1cIm5ldyBibG9nXCIgdmlzaWJsZW1lc3NhZ2U9XCJjYW5jZWxcIiByZWY9e0dsb2JhbFRvZ2dsZX0+XG4gICAgICAgICAgICAgICAgICAgIDxOZXdCbG9nIHVzZXI9e3VzZXJ9IHNlbGZUb2dnbGU9e0dsb2JhbFRvZ2dsZX0gYWRkQmxvZz17YWRkQmxvZ30gLz5cbiAgICAgICAgICAgICAgICA8L1Zpc2liaWxpdHlDb21wb25lbnQ+XG4gICAgICAgICAgICAgICAge2Jsb2dzLm1hcChibG9nID0+IDxCbG9nIGtleT17YmxvZy5pZH0gYmxvZz17YmxvZ30gdXNlcj17dXNlcn0gc2V0QmxvZ0xpc3Q9e3NldEJsb2dzfSBibG9nTGlzdD17YmxvZ3N9IGxpa2U9e2xpa2VCbG9nfS8+KX1cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8Lz5cbiAgICApXG59XG5cbmV4cG9ydCBkZWZhdWx0IFJlbmRlckJsb2ciXSwiZmlsZSI6Ii9Vc2Vycy9zYWlhZGlyYWp1L0xpYnJhcnkvQ2xvdWRTdG9yYWdlL0dvb2dsZURyaXZlLXNhaWFkaTQwMDJAZ21haWwuY29tL015IERyaXZlL1Byb2dyYW1taW5nL0FwcERldi9GdWxsIFN0YWNrIE9wZW4vYmxvZ2xpc3QtZnJvbnRlbmQvc3JjL2NvbXBvbmVudHMvUmVuZGVyQmxvZy5qc3gifQ==