import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/App.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f0094fdc"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/saiadiraju/Library/CloudStorage/GoogleDrive-saiadi4002@gmail.com/My Drive/Programming/AppDev/Full Stack Open/bloglist-frontend/src/App.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=f0094fdc"; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"];
import Login from "/src/components/Login.jsx";
import RenderBlog from "/src/components/RenderBlog.jsx";
const App = () => {
  _s();
  const [user, setUser] = useState(JSON.parse(window.localStorage.getItem("user")));
  return /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV("h2", { children: "blogs" }, void 0, false, {
      fileName: "/Users/saiadiraju/Library/CloudStorage/GoogleDrive-saiadi4002@gmail.com/My Drive/Programming/AppDev/Full Stack Open/bloglist-frontend/src/App.jsx",
      lineNumber: 9,
      columnNumber: 13
    }, this),
    user === null ? /* @__PURE__ */ jsxDEV(Login, { setUser }, void 0, false, {
      fileName: "/Users/saiadiraju/Library/CloudStorage/GoogleDrive-saiadi4002@gmail.com/My Drive/Programming/AppDev/Full Stack Open/bloglist-frontend/src/App.jsx",
      lineNumber: 10,
      columnNumber: 30
    }, this) : /* @__PURE__ */ jsxDEV(RenderBlog, { setUser, user }, void 0, false, {
      fileName: "/Users/saiadiraju/Library/CloudStorage/GoogleDrive-saiadi4002@gmail.com/My Drive/Programming/AppDev/Full Stack Open/bloglist-frontend/src/App.jsx",
      lineNumber: 10,
      columnNumber: 60
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/saiadiraju/Library/CloudStorage/GoogleDrive-saiadi4002@gmail.com/My Drive/Programming/AppDev/Full Stack Open/bloglist-frontend/src/App.jsx",
    lineNumber: 8,
    columnNumber: 10
  }, this);
};
_s(App, "KBGRr7c6vkHFKBiSsTL0IkwRRfg=");
_c = App;
export default App;
var _c;
$RefreshReg$(_c, "App");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/saiadiraju/Library/CloudStorage/GoogleDrive-saiadi4002@gmail.com/My Drive/Programming/AppDev/Full Stack Open/bloglist-frontend/src/App.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBU1k7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBVFosU0FBU0EsVUFBVUMsaUJBQWlCO0FBQ3BDLE9BQU9DLFdBQVc7QUFDbEIsT0FBT0MsZ0JBQWdCO0FBRXZCLE1BQU1DLE1BQU1BLE1BQU07QUFBQUMsS0FBQTtBQUNkLFFBQU0sQ0FBQ0MsTUFBTUMsT0FBTyxJQUFJUCxTQUFTUSxLQUFLQyxNQUFNQyxPQUFPQyxhQUFhQyxRQUFRLE1BQU0sQ0FBQyxDQUFDO0FBRWhGLFNBQ0ksdUJBQUMsU0FDRztBQUFBLDJCQUFDLFFBQUcscUJBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFTO0FBQUEsSUFDUk4sU0FBUyxPQUFPLHVCQUFDLFNBQU0sV0FBUDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXdCLElBQU0sdUJBQUMsY0FBVyxTQUFrQixRQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXlDO0FBQUEsT0FGNUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUdBO0FBRVI7QUFBQ0QsR0FUS0QsS0FBRztBQUFBUyxLQUFIVDtBQVdOLGVBQWVBO0FBQUcsSUFBQVM7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwidXNlRWZmZWN0IiwiTG9naW4iLCJSZW5kZXJCbG9nIiwiQXBwIiwiX3MiLCJ1c2VyIiwic2V0VXNlciIsIkpTT04iLCJwYXJzZSIsIndpbmRvdyIsImxvY2FsU3RvcmFnZSIsImdldEl0ZW0iLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkFwcC5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUsIHVzZUVmZmVjdCB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IExvZ2luIGZyb20gJy4vY29tcG9uZW50cy9Mb2dpbidcbmltcG9ydCBSZW5kZXJCbG9nIGZyb20gJy4vY29tcG9uZW50cy9SZW5kZXJCbG9nJ1xuXG5jb25zdCBBcHAgPSAoKSA9PiB7XG4gICAgY29uc3QgW3VzZXIsIHNldFVzZXJdID0gdXNlU3RhdGUoSlNPTi5wYXJzZSh3aW5kb3cubG9jYWxTdG9yYWdlLmdldEl0ZW0oJ3VzZXInKSkpXG5cbiAgICByZXR1cm4gKFxuICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgPGgyPmJsb2dzPC9oMj5cbiAgICAgICAgICAgIHt1c2VyID09PSBudWxsID8gPExvZ2luIHNldFVzZXI9e3NldFVzZXJ9IC8+IDogPFJlbmRlckJsb2cgc2V0VXNlcj17c2V0VXNlcn0gdXNlcj17dXNlcn0vPn1cbiAgICAgICAgPC9kaXY+XG4gICAgKVxufVxuXG5leHBvcnQgZGVmYXVsdCBBcHAiXSwiZmlsZSI6Ii9Vc2Vycy9zYWlhZGlyYWp1L0xpYnJhcnkvQ2xvdWRTdG9yYWdlL0dvb2dsZURyaXZlLXNhaWFkaTQwMDJAZ21haWwuY29tL015IERyaXZlL1Byb2dyYW1taW5nL0FwcERldi9GdWxsIFN0YWNrIE9wZW4vYmxvZ2xpc3QtZnJvbnRlbmQvc3JjL0FwcC5qc3gifQ==