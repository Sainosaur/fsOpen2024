import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Blog.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f0094fdc"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/saiadiraju/Library/CloudStorage/GoogleDrive-saiadi4002@gmail.com/My Drive/Programming/AppDev/Full Stack Open/bloglist-frontend/src/components/Blog.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=f0094fdc"; const useState = __vite__cjsImport3_react["useState"];
import BlogService from "/src/services/blogs.js";
const Blog = ({
  blog,
  user,
  setBlogList,
  blogList,
  like
}) => {
  _s();
  const blogStyle = {
    color: "blue",
    paddingTop: 10,
    paddingLeft: 2,
    border: "solid",
    borderWidth: 1,
    marginBottom: 5
  };
  const [disp, setDisp] = useState([{
    display: "none"
  }, "View"]);
  const [likes, setLikes] = useState(blog.likes);
  const toggleVisibility = () => {
    if (disp[1] === "View") {
      setDisp([{}, "Hide"]);
    } else if (disp[1] === "Hide") {
      setDisp([{
        display: "none"
      }, "View"]);
    }
  };
  const likeBlog = () => {
    like(blog, user);
    setLikes(likes + 1);
  };
  const deleteBlog = () => {
    try {
      window.confirm("Are you sure you would like to delete this blog?") ? BlogService.deleteBlog(blog) : null;
      setBlogList(blogList.filter((blog1) => blog1 !== blog));
    } catch {
      window.alert("Error! Cannot delete blog, please try again later");
    }
  };
  return /* @__PURE__ */ jsxDEV("div", { style: blogStyle, children: [
    /* @__PURE__ */ jsxDEV("p", { children: [
      blog.title,
      " ",
      blog.author,
      " ",
      /* @__PURE__ */ jsxDEV("button", { onClick: () => toggleVisibility(), children: disp[1] }, void 0, false, {
        fileName: "/Users/saiadiraju/Library/CloudStorage/GoogleDrive-saiadi4002@gmail.com/My Drive/Programming/AppDev/Full Stack Open/bloglist-frontend/src/components/Blog.jsx",
        lineNumber: 47,
        columnNumber: 43
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/saiadiraju/Library/CloudStorage/GoogleDrive-saiadi4002@gmail.com/My Drive/Programming/AppDev/Full Stack Open/bloglist-frontend/src/components/Blog.jsx",
      lineNumber: 47,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { style: disp[0], className: "toggleVis", children: [
      /* @__PURE__ */ jsxDEV("p", { children: [
        "url: ",
        blog.url
      ] }, void 0, true, {
        fileName: "/Users/saiadiraju/Library/CloudStorage/GoogleDrive-saiadi4002@gmail.com/My Drive/Programming/AppDev/Full Stack Open/bloglist-frontend/src/components/Blog.jsx",
        lineNumber: 49,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "likeCount", children: [
        "likes: ",
        likes,
        /* @__PURE__ */ jsxDEV("button", { onClick: () => likeBlog(), children: "like" }, void 0, false, {
          fileName: "/Users/saiadiraju/Library/CloudStorage/GoogleDrive-saiadi4002@gmail.com/My Drive/Programming/AppDev/Full Stack Open/bloglist-frontend/src/components/Blog.jsx",
          lineNumber: 50,
          columnNumber: 56
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/saiadiraju/Library/CloudStorage/GoogleDrive-saiadi4002@gmail.com/My Drive/Programming/AppDev/Full Stack Open/bloglist-frontend/src/components/Blog.jsx",
        lineNumber: 50,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("p", { children: [
        "user: ",
        blog.user ? blog.user.name : "not found"
      ] }, void 0, true, {
        fileName: "/Users/saiadiraju/Library/CloudStorage/GoogleDrive-saiadi4002@gmail.com/My Drive/Programming/AppDev/Full Stack Open/bloglist-frontend/src/components/Blog.jsx",
        lineNumber: 51,
        columnNumber: 17
      }, this),
      blog.user.id === user.id ? /* @__PURE__ */ jsxDEV("button", { onClick: () => deleteBlog(), children: "remove" }, void 0, false, {
        fileName: "/Users/saiadiraju/Library/CloudStorage/GoogleDrive-saiadi4002@gmail.com/My Drive/Programming/AppDev/Full Stack Open/bloglist-frontend/src/components/Blog.jsx",
        lineNumber: 52,
        columnNumber: 45
      }, this) : null
    ] }, void 0, true, {
      fileName: "/Users/saiadiraju/Library/CloudStorage/GoogleDrive-saiadi4002@gmail.com/My Drive/Programming/AppDev/Full Stack Open/bloglist-frontend/src/components/Blog.jsx",
      lineNumber: 48,
      columnNumber: 13
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/saiadiraju/Library/CloudStorage/GoogleDrive-saiadi4002@gmail.com/My Drive/Programming/AppDev/Full Stack Open/bloglist-frontend/src/components/Blog.jsx",
    lineNumber: 46,
    columnNumber: 10
  }, this);
};
_s(Blog, "oCuoEZHtOMeluAwn1dwq2Fb/F7s=");
_c = Blog;
export default Blog;
var _c;
$RefreshReg$(_c, "Blog");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/saiadiraju/Library/CloudStorage/GoogleDrive-saiadi4002@gmail.com/My Drive/Programming/AppDev/Full Stack Open/bloglist-frontend/src/components/Blog.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBc0MwQzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUF0QzFDLFNBQVNBLGdCQUFnQjtBQUN6QixPQUFPQyxpQkFBaUI7QUFFeEIsTUFBTUMsT0FBT0EsQ0FBQztBQUFBLEVBQUVDO0FBQUFBLEVBQU1DO0FBQUFBLEVBQU1DO0FBQUFBLEVBQWFDO0FBQUFBLEVBQVVDO0FBQUssTUFBTTtBQUFBQyxLQUFBO0FBQzFELFFBQU1DLFlBQVk7QUFBQSxJQUNkQyxPQUFPO0FBQUEsSUFDUEMsWUFBWTtBQUFBLElBQ1pDLGFBQWE7QUFBQSxJQUNiQyxRQUFRO0FBQUEsSUFDUkMsYUFBYTtBQUFBLElBQ2JDLGNBQWM7QUFBQSxFQUNsQjtBQUNBLFFBQU0sQ0FBQ0MsTUFBTUMsT0FBTyxJQUFJakIsU0FBUyxDQUFDO0FBQUEsSUFBRWtCLFNBQVM7QUFBQSxFQUFPLEdBQUcsTUFBTSxDQUFDO0FBRTlELFFBQU0sQ0FBQ0MsT0FBT0MsUUFBUSxJQUFJcEIsU0FBU0csS0FBS2dCLEtBQUs7QUFDN0MsUUFBTUUsbUJBQW1CQSxNQUFNO0FBQzNCLFFBQUlMLEtBQUssQ0FBQyxNQUFNLFFBQVE7QUFDcEJDLGNBQVEsQ0FBQyxDQUFDLEdBQUcsTUFBTSxDQUFDO0FBQUEsSUFDeEIsV0FBV0QsS0FBSyxDQUFDLE1BQU0sUUFBUTtBQUMzQkMsY0FBUSxDQUFDO0FBQUEsUUFBRUMsU0FBUztBQUFBLE1BQU8sR0FBRSxNQUFNLENBQUM7QUFBQSxJQUN4QztBQUFBLEVBQ0o7QUFDQSxRQUFNSSxXQUFXQSxNQUFNO0FBQ25CZixTQUFLSixNQUFNQyxJQUFJO0FBQ2ZnQixhQUFTRCxRQUFRLENBQUM7QUFBQSxFQUN0QjtBQUNBLFFBQU1JLGFBQWFBLE1BQU07QUFDckIsUUFBSTtBQUNBQyxhQUFPQyxRQUFRLGtEQUFrRCxJQUFJeEIsWUFBWXNCLFdBQVdwQixJQUFJLElBQUk7QUFDcEdFLGtCQUFZQyxTQUFTb0IsT0FBUUMsV0FBVUEsVUFBVXhCLElBQUssQ0FBQztBQUFBLElBRTNELFFBQVE7QUFDSnFCLGFBQU9JLE1BQU0sbURBQW1EO0FBQUEsSUFDcEU7QUFBQSxFQUNKO0FBRUEsU0FDSSx1QkFBQyxTQUFJLE9BQU9uQixXQUNSO0FBQUEsMkJBQUMsT0FBR047QUFBQUEsV0FBSzBCO0FBQUFBLE1BQU07QUFBQSxNQUFFMUIsS0FBSzJCO0FBQUFBLE1BQU87QUFBQSxNQUFDLHVCQUFDLFlBQU8sU0FBUyxNQUFNVCxpQkFBaUIsR0FBSUwsZUFBSyxDQUFDLEtBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBb0Q7QUFBQSxTQUFsRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTJGO0FBQUEsSUFDM0YsdUJBQUMsU0FBSSxPQUFPQSxLQUFLLENBQUMsR0FBRyxXQUFVLGFBQzNCO0FBQUEsNkJBQUMsT0FBRTtBQUFBO0FBQUEsUUFBTWIsS0FBSzRCO0FBQUFBLFdBQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFrQjtBQUFBLE1BQ2xCLHVCQUFDLE9BQUUsV0FBVSxhQUFZO0FBQUE7QUFBQSxRQUFRWjtBQUFBQSxRQUFNLHVCQUFDLFlBQU8sU0FBUyxNQUFNRyxTQUFTLEdBQUcsb0JBQW5DO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBdUM7QUFBQSxXQUE5RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXVGO0FBQUEsTUFDdkYsdUJBQUMsT0FBRTtBQUFBO0FBQUEsUUFBT25CLEtBQUtDLE9BQU9ELEtBQUtDLEtBQUs0QixPQUFPO0FBQUEsV0FBdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFtRDtBQUFBLE1BQ2xEN0IsS0FBS0MsS0FBSzZCLE9BQU83QixLQUFLNkIsS0FBSyx1QkFBQyxZQUFPLFNBQVMsTUFBTVYsV0FBVyxHQUFHLHNCQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTJDLElBQVk7QUFBQSxTQUp2RjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBS0E7QUFBQSxPQVBKO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FRQTtBQUVSO0FBQUNmLEdBNUNLTixNQUFJO0FBQUFnQyxLQUFKaEM7QUE4Q04sZUFBZUE7QUFBSSxJQUFBZ0M7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwiQmxvZ1NlcnZpY2UiLCJCbG9nIiwiYmxvZyIsInVzZXIiLCJzZXRCbG9nTGlzdCIsImJsb2dMaXN0IiwibGlrZSIsIl9zIiwiYmxvZ1N0eWxlIiwiY29sb3IiLCJwYWRkaW5nVG9wIiwicGFkZGluZ0xlZnQiLCJib3JkZXIiLCJib3JkZXJXaWR0aCIsIm1hcmdpbkJvdHRvbSIsImRpc3AiLCJzZXREaXNwIiwiZGlzcGxheSIsImxpa2VzIiwic2V0TGlrZXMiLCJ0b2dnbGVWaXNpYmlsaXR5IiwibGlrZUJsb2ciLCJkZWxldGVCbG9nIiwid2luZG93IiwiY29uZmlybSIsImZpbHRlciIsImJsb2cxIiwiYWxlcnQiLCJ0aXRsZSIsImF1dGhvciIsInVybCIsIm5hbWUiLCJpZCIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiQmxvZy5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCdcbmltcG9ydCBCbG9nU2VydmljZSBmcm9tICcuLi9zZXJ2aWNlcy9ibG9ncydcblxuY29uc3QgQmxvZyA9ICh7IGJsb2csIHVzZXIsIHNldEJsb2dMaXN0LCBibG9nTGlzdCwgbGlrZSB9KSA9PiB7XG4gICAgY29uc3QgYmxvZ1N0eWxlID0ge1xuICAgICAgICBjb2xvcjogJ2JsdWUnLFxuICAgICAgICBwYWRkaW5nVG9wOiAxMCxcbiAgICAgICAgcGFkZGluZ0xlZnQ6IDIsXG4gICAgICAgIGJvcmRlcjogJ3NvbGlkJyxcbiAgICAgICAgYm9yZGVyV2lkdGg6IDEsXG4gICAgICAgIG1hcmdpbkJvdHRvbTogNVxuICAgIH1cbiAgICBjb25zdCBbZGlzcCwgc2V0RGlzcF0gPSB1c2VTdGF0ZShbeyBkaXNwbGF5OiAnbm9uZScgfSwgJ1ZpZXcnXSlcbiAgICAvLyBTdGF0ZSB1c2VkIHRvIGhhbmRsZSBsaWtlcyBzbyB0aGF0IHRoZSBjb21wb25lbnQgcmVsb2FkcyB3aGVuIHRoZSBsaWtlIGJ1dHRvbiBpcyBwcmVzc2VkXG4gICAgY29uc3QgW2xpa2VzLCBzZXRMaWtlc10gPSB1c2VTdGF0ZShibG9nLmxpa2VzKVxuICAgIGNvbnN0IHRvZ2dsZVZpc2liaWxpdHkgPSAoKSA9PiB7XG4gICAgICAgIGlmIChkaXNwWzFdID09PSAnVmlldycpIHtcbiAgICAgICAgICAgIHNldERpc3AoW3t9LCAnSGlkZSddKVxuICAgICAgICB9IGVsc2UgaWYgKGRpc3BbMV0gPT09ICdIaWRlJykge1xuICAgICAgICAgICAgc2V0RGlzcChbeyBkaXNwbGF5OiAnbm9uZScgfSwnVmlldyddKVxuICAgICAgICB9XG4gICAgfVxuICAgIGNvbnN0IGxpa2VCbG9nID0gKCkgPT4ge1xuICAgICAgICBsaWtlKGJsb2csIHVzZXIpXG4gICAgICAgIHNldExpa2VzKGxpa2VzICsgMSlcbiAgICB9XG4gICAgY29uc3QgZGVsZXRlQmxvZyA9ICgpID0+IHtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIHdpbmRvdy5jb25maXJtKCdBcmUgeW91IHN1cmUgeW91IHdvdWxkIGxpa2UgdG8gZGVsZXRlIHRoaXMgYmxvZz8nKSA/IEJsb2dTZXJ2aWNlLmRlbGV0ZUJsb2coYmxvZykgOiBudWxsXG4gICAgICAgICAgICBzZXRCbG9nTGlzdChibG9nTGlzdC5maWx0ZXIoKGJsb2cxKSA9PiBibG9nMSAhPT0gYmxvZywpKVxuXG4gICAgICAgIH0gY2F0Y2gge1xuICAgICAgICAgICAgd2luZG93LmFsZXJ0KCdFcnJvciEgQ2Fubm90IGRlbGV0ZSBibG9nLCBwbGVhc2UgdHJ5IGFnYWluIGxhdGVyJylcbiAgICAgICAgfVxuICAgIH1cblxuICAgIHJldHVybiAoXG4gICAgICAgIDxkaXYgc3R5bGU9e2Jsb2dTdHlsZX0+XG4gICAgICAgICAgICA8cD57YmxvZy50aXRsZX0ge2Jsb2cuYXV0aG9yfSA8YnV0dG9uIG9uQ2xpY2s9eygpID0+IHRvZ2dsZVZpc2liaWxpdHkoKX0+e2Rpc3BbMV19PC9idXR0b24+PC9wPlxuICAgICAgICAgICAgPGRpdiBzdHlsZT17ZGlzcFswXX0gY2xhc3NOYW1lPSd0b2dnbGVWaXMnPlxuICAgICAgICAgICAgICAgIDxwPnVybDoge2Jsb2cudXJsfTwvcD5cbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9J2xpa2VDb3VudCc+bGlrZXM6IHtsaWtlc308YnV0dG9uIG9uQ2xpY2s9eygpID0+IGxpa2VCbG9nKCl9Pmxpa2U8L2J1dHRvbj48L3A+XG4gICAgICAgICAgICAgICAgPHA+dXNlcjoge2Jsb2cudXNlciA/IGJsb2cudXNlci5uYW1lIDogJ25vdCBmb3VuZCd9PC9wPlxuICAgICAgICAgICAgICAgIHtibG9nLnVzZXIuaWQgPT09IHVzZXIuaWQgPyA8YnV0dG9uIG9uQ2xpY2s9eygpID0+IGRlbGV0ZUJsb2coKX0+cmVtb3ZlPC9idXR0b24+IDogbnVsbH1cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICApXG59XG5cbmV4cG9ydCBkZWZhdWx0IEJsb2ciXSwiZmlsZSI6Ii9Vc2Vycy9zYWlhZGlyYWp1L0xpYnJhcnkvQ2xvdWRTdG9yYWdlL0dvb2dsZURyaXZlLXNhaWFkaTQwMDJAZ21haWwuY29tL015IERyaXZlL1Byb2dyYW1taW5nL0FwcERldi9GdWxsIFN0YWNrIE9wZW4vYmxvZ2xpc3QtZnJvbnRlbmQvc3JjL2NvbXBvbmVudHMvQmxvZy5qc3gifQ==