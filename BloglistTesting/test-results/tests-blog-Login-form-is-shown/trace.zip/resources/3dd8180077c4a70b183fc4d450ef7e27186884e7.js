import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/NewBlog.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f0094fdc"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/saiadiraju/Library/CloudStorage/GoogleDrive-saiadi4002@gmail.com/My Drive/Programming/AppDev/Full Stack Open/bloglist-frontend/src/components/NewBlog.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=f0094fdc"; const useState = __vite__cjsImport3_react["useState"];
import Notification from "/src/components/Notification.jsx";
const NewBlog = (props) => {
  _s();
  const [title, setTitle] = useState("");
  const [author, setAuthor] = useState("");
  const [url, setUrl] = useState("");
  const [message, setMessage] = useState(["null", "green"]);
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(Notification, { message: message[0], color: message[1] }, void 0, false, {
      fileName: "/Users/saiadiraju/Library/CloudStorage/GoogleDrive-saiadi4002@gmail.com/My Drive/Programming/AppDev/Full Stack Open/bloglist-frontend/src/components/NewBlog.jsx",
      lineNumber: 11,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { children: [
      /* @__PURE__ */ jsxDEV("h2", { children: "Create new:" }, void 0, false, {
        fileName: "/Users/saiadiraju/Library/CloudStorage/GoogleDrive-saiadi4002@gmail.com/My Drive/Programming/AppDev/Full Stack Open/bloglist-frontend/src/components/NewBlog.jsx",
        lineNumber: 13,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("p", { children: [
        "title: ",
        /* @__PURE__ */ jsxDEV("input", { value: title, onChange: ({
          target
        }) => setTitle(target.value), className: "Title" }, void 0, false, {
          fileName: "/Users/saiadiraju/Library/CloudStorage/GoogleDrive-saiadi4002@gmail.com/My Drive/Programming/AppDev/Full Stack Open/bloglist-frontend/src/components/NewBlog.jsx",
          lineNumber: 14,
          columnNumber: 27
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/saiadiraju/Library/CloudStorage/GoogleDrive-saiadi4002@gmail.com/My Drive/Programming/AppDev/Full Stack Open/bloglist-frontend/src/components/NewBlog.jsx",
        lineNumber: 14,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("p", { children: [
        "author: ",
        /* @__PURE__ */ jsxDEV("input", { value: author, onChange: ({
          target
        }) => setAuthor(target.value), className: "Author" }, void 0, false, {
          fileName: "/Users/saiadiraju/Library/CloudStorage/GoogleDrive-saiadi4002@gmail.com/My Drive/Programming/AppDev/Full Stack Open/bloglist-frontend/src/components/NewBlog.jsx",
          lineNumber: 17,
          columnNumber: 28
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/saiadiraju/Library/CloudStorage/GoogleDrive-saiadi4002@gmail.com/My Drive/Programming/AppDev/Full Stack Open/bloglist-frontend/src/components/NewBlog.jsx",
        lineNumber: 17,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("p", { children: [
        "url: ",
        /* @__PURE__ */ jsxDEV("input", { value: url, onChange: ({
          target
        }) => setUrl(target.value), className: "Url" }, void 0, false, {
          fileName: "/Users/saiadiraju/Library/CloudStorage/GoogleDrive-saiadi4002@gmail.com/My Drive/Programming/AppDev/Full Stack Open/bloglist-frontend/src/components/NewBlog.jsx",
          lineNumber: 20,
          columnNumber: 25
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/saiadiraju/Library/CloudStorage/GoogleDrive-saiadi4002@gmail.com/My Drive/Programming/AppDev/Full Stack Open/bloglist-frontend/src/components/NewBlog.jsx",
        lineNumber: 20,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("button", { onClick: () => {
        props.addBlog(title, author, url, props.user, setMessage, props.selfToggle.current.toggleVisibility);
      }, children: "create" }, void 0, false, {
        fileName: "/Users/saiadiraju/Library/CloudStorage/GoogleDrive-saiadi4002@gmail.com/My Drive/Programming/AppDev/Full Stack Open/bloglist-frontend/src/components/NewBlog.jsx",
        lineNumber: 23,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/saiadiraju/Library/CloudStorage/GoogleDrive-saiadi4002@gmail.com/My Drive/Programming/AppDev/Full Stack Open/bloglist-frontend/src/components/NewBlog.jsx",
      lineNumber: 12,
      columnNumber: 13
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/saiadiraju/Library/CloudStorage/GoogleDrive-saiadi4002@gmail.com/My Drive/Programming/AppDev/Full Stack Open/bloglist-frontend/src/components/NewBlog.jsx",
    lineNumber: 10,
    columnNumber: 10
  }, this);
};
_s(NewBlog, "sXZ+t9A5OpY8vk9p+MFMhXV93ys=");
_c = NewBlog;
export default NewBlog;
var _c;
$RefreshReg$(_c, "NewBlog");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/saiadiraju/Library/CloudStorage/GoogleDrive-saiadi4002@gmail.com/My Drive/Programming/AppDev/Full Stack Open/bloglist-frontend/src/components/NewBlog.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBVVEsbUJBQ0ksY0FESjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFWUixTQUFTQSxnQkFBZ0I7QUFDekIsT0FBT0Msa0JBQWtCO0FBRXpCLE1BQU1DLFVBQVdDLFdBQVU7QUFBQUMsS0FBQTtBQUN2QixRQUFNLENBQUNDLE9BQU9DLFFBQVEsSUFBSU4sU0FBUyxFQUFFO0FBQ3JDLFFBQU0sQ0FBQ08sUUFBUUMsU0FBUyxJQUFJUixTQUFTLEVBQUU7QUFDdkMsUUFBTSxDQUFDUyxLQUFLQyxNQUFNLElBQUlWLFNBQVMsRUFBRTtBQUNqQyxRQUFNLENBQUNXLFNBQVNDLFVBQVUsSUFBSVosU0FBUyxDQUFDLFFBQU8sT0FBTyxDQUFDO0FBRXZELFNBQ0ksbUNBQ0k7QUFBQSwyQkFBQyxnQkFBYSxTQUFTVyxRQUFRLENBQUMsR0FBRyxPQUFPQSxRQUFRLENBQUMsS0FBbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFxRDtBQUFBLElBQ3JELHVCQUFDLFNBQ0c7QUFBQSw2QkFBQyxRQUFHLDJCQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBZTtBQUFBLE1BQ2YsdUJBQUMsT0FBRTtBQUFBO0FBQUEsUUFBTyx1QkFBQyxXQUFNLE9BQU9OLE9BQU8sVUFBVSxDQUFDO0FBQUEsVUFBRVE7QUFBQUEsUUFBTyxNQUFNUCxTQUFTTyxPQUFPQyxLQUFLLEdBQUcsV0FBVSxXQUFqRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXlGO0FBQUEsV0FBbkc7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUEyRztBQUFBLE1BQzNHLHVCQUFDLE9BQUU7QUFBQTtBQUFBLFFBQVEsdUJBQUMsV0FBTSxPQUFPUCxRQUFRLFVBQVUsQ0FBQztBQUFBLFVBQUVNO0FBQUFBLFFBQU8sTUFBTUwsVUFBVUssT0FBT0MsS0FBSyxHQUFHLFdBQVUsWUFBbkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE0RjtBQUFBLFdBQXZHO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBK0c7QUFBQSxNQUMvRyx1QkFBQyxPQUFFO0FBQUE7QUFBQSxRQUFLLHVCQUFDLFdBQU0sT0FBT0wsS0FBSyxVQUFVLENBQUM7QUFBQSxVQUFFSTtBQUFBQSxRQUFPLE1BQU1ILE9BQU9HLE9BQU9DLEtBQUssR0FBRyxXQUFVLFNBQTdFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBbUY7QUFBQSxXQUEzRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW1HO0FBQUEsTUFDbkcsdUJBQUMsWUFBTyxTQUFTLE1BQU07QUFDbkJYLGNBQU1ZLFFBQVFWLE9BQU9FLFFBQVFFLEtBQUtOLE1BQU1hLE1BQU1KLFlBQVlULE1BQU1jLFdBQVdDLFFBQVFDLGdCQUFnQjtBQUFBLE1BQ3ZHLEdBQUcsc0JBRkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVTO0FBQUEsU0FQYjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBUUE7QUFBQSxPQVZKO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FXQTtBQUVSO0FBQUNmLEdBcEJLRixTQUFPO0FBQUFrQixLQUFQbEI7QUFzQk4sZUFBZUE7QUFBTyxJQUFBa0I7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwiTm90aWZpY2F0aW9uIiwiTmV3QmxvZyIsInByb3BzIiwiX3MiLCJ0aXRsZSIsInNldFRpdGxlIiwiYXV0aG9yIiwic2V0QXV0aG9yIiwidXJsIiwic2V0VXJsIiwibWVzc2FnZSIsInNldE1lc3NhZ2UiLCJ0YXJnZXQiLCJ2YWx1ZSIsImFkZEJsb2ciLCJ1c2VyIiwic2VsZlRvZ2dsZSIsImN1cnJlbnQiLCJ0b2dnbGVWaXNpYmlsaXR5IiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJOZXdCbG9nLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IE5vdGlmaWNhdGlvbiBmcm9tICcuL05vdGlmaWNhdGlvbidcblxuY29uc3QgTmV3QmxvZyA9IChwcm9wcykgPT4ge1xuICAgIGNvbnN0IFt0aXRsZSwgc2V0VGl0bGVdID0gdXNlU3RhdGUoJycpXG4gICAgY29uc3QgW2F1dGhvciwgc2V0QXV0aG9yXSA9IHVzZVN0YXRlKCcnKVxuICAgIGNvbnN0IFt1cmwsIHNldFVybF0gPSB1c2VTdGF0ZSgnJylcbiAgICBjb25zdCBbbWVzc2FnZSwgc2V0TWVzc2FnZV0gPSB1c2VTdGF0ZShbJ251bGwnLCdncmVlbiddKVxuXG4gICAgcmV0dXJuIChcbiAgICAgICAgPD5cbiAgICAgICAgICAgIDxOb3RpZmljYXRpb24gbWVzc2FnZT17bWVzc2FnZVswXX0gY29sb3I9e21lc3NhZ2VbMV19IC8+XG4gICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgIDxoMj5DcmVhdGUgbmV3OjwvaDI+XG4gICAgICAgICAgICAgICAgPHA+dGl0bGU6IDxpbnB1dCB2YWx1ZT17dGl0bGV9IG9uQ2hhbmdlPXsoeyB0YXJnZXQgfSkgPT4gc2V0VGl0bGUodGFyZ2V0LnZhbHVlKX0gY2xhc3NOYW1lPSdUaXRsZSc+PC9pbnB1dD48L3A+XG4gICAgICAgICAgICAgICAgPHA+YXV0aG9yOiA8aW5wdXQgdmFsdWU9e2F1dGhvcn0gb25DaGFuZ2U9eyh7IHRhcmdldCB9KSA9PiBzZXRBdXRob3IodGFyZ2V0LnZhbHVlKX0gY2xhc3NOYW1lPSdBdXRob3InPjwvaW5wdXQ+PC9wPlxuICAgICAgICAgICAgICAgIDxwPnVybDogPGlucHV0IHZhbHVlPXt1cmx9IG9uQ2hhbmdlPXsoeyB0YXJnZXQgfSkgPT4gc2V0VXJsKHRhcmdldC52YWx1ZSl9IGNsYXNzTmFtZT0nVXJsJz48L2lucHV0PjwvcD5cbiAgICAgICAgICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9eygpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgcHJvcHMuYWRkQmxvZyh0aXRsZSwgYXV0aG9yLCB1cmwsIHByb3BzLnVzZXIsIHNldE1lc3NhZ2UsIHByb3BzLnNlbGZUb2dnbGUuY3VycmVudC50b2dnbGVWaXNpYmlsaXR5KVxuICAgICAgICAgICAgICAgIH19PmNyZWF0ZTwvYnV0dG9uPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvPlxuICAgIClcbn1cblxuZXhwb3J0IGRlZmF1bHQgTmV3QmxvZyJdLCJmaWxlIjoiL1VzZXJzL3NhaWFkaXJhanUvTGlicmFyeS9DbG91ZFN0b3JhZ2UvR29vZ2xlRHJpdmUtc2FpYWRpNDAwMkBnbWFpbC5jb20vTXkgRHJpdmUvUHJvZ3JhbW1pbmcvQXBwRGV2L0Z1bGwgU3RhY2sgT3Blbi9ibG9nbGlzdC1mcm9udGVuZC9zcmMvY29tcG9uZW50cy9OZXdCbG9nLmpzeCJ9