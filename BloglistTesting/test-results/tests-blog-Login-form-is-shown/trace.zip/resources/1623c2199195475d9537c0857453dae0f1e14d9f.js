import {
  require_react
} from "/node_modules/.vite/deps/chunk-7JGOPB4S.js?v=f0094fdc";
import "/node_modules/.vite/deps/chunk-6TJCVOLN.js?v=f0094fdc";
export default require_react();
//# sourceMappingURL=react.js.map
