import axios from "/node_modules/.vite/deps/axios.js?v=f0094fdc"
const baseUrl = 'http://localhost:3003/api/login/'

const loginService = (user, password) => {
    const config = {
        username : user,
        password : password
    }
    const response = axios.post(baseUrl, config)
    return response
}

export default loginService