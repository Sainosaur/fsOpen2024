import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Login.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f0094fdc"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/saiadiraju/Library/CloudStorage/GoogleDrive-saiadi4002@gmail.com/My Drive/Programming/AppDev/Full Stack Open/bloglist-frontend/src/components/Login.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import loginService from "/src/services/login.js";
import Notification from "/src/components/Notification.jsx";
import __vite__cjsImport5_react from "/node_modules/.vite/deps/react.js?v=f0094fdc"; const useState = __vite__cjsImport5_react["useState"];
const Login = ({
  setUser
}) => {
  _s();
  const [usr, setUsr] = useState("");
  const [pwd, setPwd] = useState("");
  const [message, setMessage] = useState(["null", "red"]);
  const updateUsr = (event2) => {
    setUsr(event2.target.value);
  };
  const updatePwd = (event2) => {
    setPwd(event2.target.value);
  };
  const obtainToken = () => {
    loginService(usr, pwd).then((response) => {
      window.localStorage.setItem("user", JSON.stringify(response.data));
      setUser(response.data);
    }).catch(
      // waits for half a second before setting error message to ensure the request has actually failed
      setTimeout(() => {
        setMessage(["wrong username or password", "red"]);
      }, "500"),
      setTimeout(() => {
        setMessage(["null", "red"]);
      }, "5000")
    );
  };
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(Notification, { message: message[0], color: message[1] }, void 0, false, {
      fileName: "/Users/saiadiraju/Library/CloudStorage/GoogleDrive-saiadi4002@gmail.com/My Drive/Programming/AppDev/Full Stack Open/bloglist-frontend/src/components/Login.jsx",
      lineNumber: 31,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { children: [
      /* @__PURE__ */ jsxDEV("p", { children: [
        "username: ",
        /* @__PURE__ */ jsxDEV("input", { value: usr, onChange: () => updateUsr(event), className: "UserField" }, void 0, false, {
          fileName: "/Users/saiadiraju/Library/CloudStorage/GoogleDrive-saiadi4002@gmail.com/My Drive/Programming/AppDev/Full Stack Open/bloglist-frontend/src/components/Login.jsx",
          lineNumber: 33,
          columnNumber: 30
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/saiadiraju/Library/CloudStorage/GoogleDrive-saiadi4002@gmail.com/My Drive/Programming/AppDev/Full Stack Open/bloglist-frontend/src/components/Login.jsx",
        lineNumber: 33,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("p", { children: [
        "password: ",
        /* @__PURE__ */ jsxDEV("input", { value: pwd, onChange: () => updatePwd(event), type: "password", className: "PwdField" }, void 0, false, {
          fileName: "/Users/saiadiraju/Library/CloudStorage/GoogleDrive-saiadi4002@gmail.com/My Drive/Programming/AppDev/Full Stack Open/bloglist-frontend/src/components/Login.jsx",
          lineNumber: 34,
          columnNumber: 30
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/saiadiraju/Library/CloudStorage/GoogleDrive-saiadi4002@gmail.com/My Drive/Programming/AppDev/Full Stack Open/bloglist-frontend/src/components/Login.jsx",
        lineNumber: 34,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("button", { onClick: () => obtainToken(), children: "Submit" }, void 0, false, {
        fileName: "/Users/saiadiraju/Library/CloudStorage/GoogleDrive-saiadi4002@gmail.com/My Drive/Programming/AppDev/Full Stack Open/bloglist-frontend/src/components/Login.jsx",
        lineNumber: 35,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/saiadiraju/Library/CloudStorage/GoogleDrive-saiadi4002@gmail.com/My Drive/Programming/AppDev/Full Stack Open/bloglist-frontend/src/components/Login.jsx",
      lineNumber: 32,
      columnNumber: 13
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/saiadiraju/Library/CloudStorage/GoogleDrive-saiadi4002@gmail.com/My Drive/Programming/AppDev/Full Stack Open/bloglist-frontend/src/components/Login.jsx",
    lineNumber: 30,
    columnNumber: 10
  }, this);
};
_s(Login, "TtSPwU9ogkvO+F6aQeGQarZYA9A=");
_c = Login;
export default Login;
var _c;
$RefreshReg$(_c, "Login");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/saiadiraju/Library/CloudStorage/GoogleDrive-saiadi4002@gmail.com/My Drive/Programming/AppDev/Full Stack Open/bloglist-frontend/src/components/Login.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBOEJRLG1CQUNJLGNBREo7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBOUJSLE9BQU9BLGtCQUFrQjtBQUN6QixPQUFPQyxrQkFBa0I7QUFDekIsU0FBU0MsZ0JBQWdCO0FBRXpCLE1BQU1DLFFBQVFBLENBQUM7QUFBQSxFQUFFQztBQUFRLE1BQU07QUFBQUMsS0FBQTtBQUMzQixRQUFNLENBQUNDLEtBQUtDLE1BQU0sSUFBSUwsU0FBUyxFQUFFO0FBQ2pDLFFBQU0sQ0FBQ00sS0FBS0MsTUFBTSxJQUFJUCxTQUFTLEVBQUU7QUFDakMsUUFBTSxDQUFDUSxTQUFTQyxVQUFVLElBQUlULFNBQVMsQ0FBQyxRQUFPLEtBQUssQ0FBQztBQUVyRCxRQUFNVSxZQUFhQyxZQUFVO0FBQ3pCTixXQUFPTSxPQUFNQyxPQUFPQyxLQUFLO0FBQUEsRUFDN0I7QUFDQSxRQUFNQyxZQUFhSCxZQUFVO0FBQ3pCSixXQUFPSSxPQUFNQyxPQUFPQyxLQUFLO0FBQUEsRUFDN0I7QUFDQSxRQUFNRSxjQUFjQSxNQUFNO0FBQ3RCakIsaUJBQWFNLEtBQUlFLEdBQUcsRUFBRVUsS0FBS0MsY0FBWTtBQUNuQ0MsYUFBT0MsYUFBYUMsUUFBUSxRQUFRQyxLQUFLQyxVQUFVTCxTQUFTTSxJQUFJLENBQUM7QUFDakVyQixjQUFRZSxTQUFTTSxJQUFJO0FBQUEsSUFDekIsQ0FBQyxFQUFFQztBQUFBQTtBQUFBQSxNQUVDQyxXQUFXLE1BQU07QUFDYmhCLG1CQUFXLENBQUMsOEJBQThCLEtBQUssQ0FBQztBQUFBLE1BQ3BELEdBQUcsS0FBSztBQUFBLE1BQ1JnQixXQUFXLE1BQU07QUFDYmhCLG1CQUFXLENBQUMsUUFBUSxLQUFLLENBQUM7QUFBQSxNQUM5QixHQUFHLE1BQU07QUFBQSxJQUNiO0FBQUEsRUFDSjtBQUNBLFNBQ0ksbUNBQ0k7QUFBQSwyQkFBQyxnQkFBYSxTQUFTRCxRQUFRLENBQUMsR0FBRyxPQUFPQSxRQUFRLENBQUMsS0FBbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFxRDtBQUFBLElBQ3JELHVCQUFDLFNBQ0c7QUFBQSw2QkFBQyxPQUFFO0FBQUE7QUFBQSxRQUFVLHVCQUFDLFdBQU0sT0FBT0osS0FBSyxVQUFVLE1BQU1NLFVBQVVDLEtBQUssR0FBRyxXQUFVLGVBQS9EO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMEU7QUFBQSxXQUF2RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTBGO0FBQUEsTUFDMUYsdUJBQUMsT0FBRTtBQUFBO0FBQUEsUUFBVSx1QkFBQyxXQUFNLE9BQU9MLEtBQUssVUFBVSxNQUFNUSxVQUFVSCxLQUFLLEdBQUcsTUFBSyxZQUFXLFdBQVUsY0FBL0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF5RjtBQUFBLFdBQXRHO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBd0c7QUFBQSxNQUN4Ryx1QkFBQyxZQUFPLFNBQVMsTUFBTUksWUFBWSxHQUFHLHNCQUF0QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTRDO0FBQUEsU0FIaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUlBO0FBQUEsT0FOSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBT0E7QUFFUjtBQUFDWixHQW5DS0YsT0FBSztBQUFBeUIsS0FBTHpCO0FBcUNOLGVBQWVBO0FBQUssSUFBQXlCO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJsb2dpblNlcnZpY2UiLCJOb3RpZmljYXRpb24iLCJ1c2VTdGF0ZSIsIkxvZ2luIiwic2V0VXNlciIsIl9zIiwidXNyIiwic2V0VXNyIiwicHdkIiwic2V0UHdkIiwibWVzc2FnZSIsInNldE1lc3NhZ2UiLCJ1cGRhdGVVc3IiLCJldmVudCIsInRhcmdldCIsInZhbHVlIiwidXBkYXRlUHdkIiwib2J0YWluVG9rZW4iLCJ0aGVuIiwicmVzcG9uc2UiLCJ3aW5kb3ciLCJsb2NhbFN0b3JhZ2UiLCJzZXRJdGVtIiwiSlNPTiIsInN0cmluZ2lmeSIsImRhdGEiLCJjYXRjaCIsInNldFRpbWVvdXQiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkxvZ2luLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgbG9naW5TZXJ2aWNlIGZyb20gJy4uL3NlcnZpY2VzL2xvZ2luJ1xuaW1wb3J0IE5vdGlmaWNhdGlvbiBmcm9tICcuL05vdGlmaWNhdGlvbidcbmltcG9ydCB7IHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnXG5cbmNvbnN0IExvZ2luID0gKHsgc2V0VXNlciB9KSA9PiB7XG4gICAgY29uc3QgW3Vzciwgc2V0VXNyXSA9IHVzZVN0YXRlKCcnKVxuICAgIGNvbnN0IFtwd2QsIHNldFB3ZF0gPSB1c2VTdGF0ZSgnJylcbiAgICBjb25zdCBbbWVzc2FnZSwgc2V0TWVzc2FnZV0gPSB1c2VTdGF0ZShbJ251bGwnLCdyZWQnXSlcblxuICAgIGNvbnN0IHVwZGF0ZVVzciA9IChldmVudCkgPT4ge1xuICAgICAgICBzZXRVc3IoZXZlbnQudGFyZ2V0LnZhbHVlKVxuICAgIH1cbiAgICBjb25zdCB1cGRhdGVQd2QgPSAoZXZlbnQpID0+IHtcbiAgICAgICAgc2V0UHdkKGV2ZW50LnRhcmdldC52YWx1ZSlcbiAgICB9XG4gICAgY29uc3Qgb2J0YWluVG9rZW4gPSAoKSA9PiB7XG4gICAgICAgIGxvZ2luU2VydmljZSh1c3IscHdkKS50aGVuKHJlc3BvbnNlID0+IHtcbiAgICAgICAgICAgIHdpbmRvdy5sb2NhbFN0b3JhZ2Uuc2V0SXRlbSgndXNlcicsIEpTT04uc3RyaW5naWZ5KHJlc3BvbnNlLmRhdGEpKVxuICAgICAgICAgICAgc2V0VXNlcihyZXNwb25zZS5kYXRhKVxuICAgICAgICB9KS5jYXRjaChcbiAgICAgICAgICAgIC8vIHdhaXRzIGZvciBoYWxmIGEgc2Vjb25kIGJlZm9yZSBzZXR0aW5nIGVycm9yIG1lc3NhZ2UgdG8gZW5zdXJlIHRoZSByZXF1ZXN0IGhhcyBhY3R1YWxseSBmYWlsZWRcbiAgICAgICAgICAgIHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICAgICAgICAgIHNldE1lc3NhZ2UoWyd3cm9uZyB1c2VybmFtZSBvciBwYXNzd29yZCcsICdyZWQnXSlcbiAgICAgICAgICAgIH0sICc1MDAnKSxcbiAgICAgICAgICAgIHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICAgICAgICAgIHNldE1lc3NhZ2UoWydudWxsJywgJ3JlZCddKVxuICAgICAgICAgICAgfSwgJzUwMDAnKVxuICAgICAgICApXG4gICAgfVxuICAgIHJldHVybiAoXG4gICAgICAgIDw+XG4gICAgICAgICAgICA8Tm90aWZpY2F0aW9uIG1lc3NhZ2U9e21lc3NhZ2VbMF19IGNvbG9yPXttZXNzYWdlWzFdfS8+XG4gICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgIDxwPnVzZXJuYW1lOiA8aW5wdXQgdmFsdWU9e3Vzcn0gb25DaGFuZ2U9eygpID0+IHVwZGF0ZVVzcihldmVudCl9IGNsYXNzTmFtZT0nVXNlckZpZWxkJyAvPjwvcD5cbiAgICAgICAgICAgICAgICA8cD5wYXNzd29yZDogPGlucHV0IHZhbHVlPXtwd2R9IG9uQ2hhbmdlPXsoKSA9PiB1cGRhdGVQd2QoZXZlbnQpfSB0eXBlPVwicGFzc3dvcmRcIiBjbGFzc05hbWU9J1B3ZEZpZWxkJy8+PC9wPlxuICAgICAgICAgICAgICAgIDxidXR0b24gb25DbGljaz17KCkgPT4gb2J0YWluVG9rZW4oKX0+U3VibWl0PC9idXR0b24+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC8+XG4gICAgKVxufVxuXG5leHBvcnQgZGVmYXVsdCBMb2dpbiJdLCJmaWxlIjoiL1VzZXJzL3NhaWFkaXJhanUvTGlicmFyeS9DbG91ZFN0b3JhZ2UvR29vZ2xlRHJpdmUtc2FpYWRpNDAwMkBnbWFpbC5jb20vTXkgRHJpdmUvUHJvZ3JhbW1pbmcvQXBwRGV2L0Z1bGwgU3RhY2sgT3Blbi9ibG9nbGlzdC1mcm9udGVuZC9zcmMvY29tcG9uZW50cy9Mb2dpbi5qc3gifQ==