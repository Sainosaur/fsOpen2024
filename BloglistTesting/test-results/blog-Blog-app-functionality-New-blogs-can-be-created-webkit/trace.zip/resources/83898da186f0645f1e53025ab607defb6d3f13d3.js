import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Blog.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f0094fdc"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/saiadiraju/Library/CloudStorage/GoogleDrive-saiadi4002@gmail.com/My Drive/Programming/AppDev/Full Stack Open/bloglist-frontend/src/components/Blog.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=f0094fdc"; const useState = __vite__cjsImport3_react["useState"];
import BlogService from "/src/services/blogs.js";
const Blog = ({
  blog,
  user,
  setBlogList,
  blogList,
  like
}) => {
  _s();
  const blogStyle = {
    color: "blue",
    paddingTop: 10,
    paddingLeft: 2,
    border: "solid",
    borderWidth: 1,
    marginBottom: 5
  };
  const [disp, setDisp] = useState([{
    display: "none"
  }, "View"]);
  const [likes, setLikes] = useState(blog.likes);
  const toggleVisibility = () => {
    if (disp[1] === "View") {
      setDisp([{}, "Hide"]);
    } else if (disp[1] === "Hide") {
      setDisp([{
        display: "none"
      }, "View"]);
    }
  };
  const likeBlog = () => {
    like(blog, user);
    setLikes(likes + 1);
  };
  const deleteBlog = () => {
    try {
      window.confirm("Are you sure you would like to delete this blog?") ? BlogService.deleteBlog(blog) : null;
      setBlogList(blogList.filter((blog1) => blog1 !== blog));
    } catch {
      window.alert("Error! Cannot delete blog, please try again later");
    }
  };
  return /* @__PURE__ */ jsxDEV("div", { style: blogStyle, children: [
    /* @__PURE__ */ jsxDEV("p", { children: [
      blog.title,
      " ",
      blog.author,
      " ",
      /* @__PURE__ */ jsxDEV("button", { onClick: () => toggleVisibility(), children: disp[1] }, void 0, false, {
        fileName: "/Users/saiadiraju/Library/CloudStorage/GoogleDrive-saiadi4002@gmail.com/My Drive/Programming/AppDev/Full Stack Open/bloglist-frontend/src/components/Blog.jsx",
        lineNumber: 47,
        columnNumber: 43
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/saiadiraju/Library/CloudStorage/GoogleDrive-saiadi4002@gmail.com/My Drive/Programming/AppDev/Full Stack Open/bloglist-frontend/src/components/Blog.jsx",
      lineNumber: 47,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { style: disp[0], className: "toggleVis", children: [
      /* @__PURE__ */ jsxDEV("p", { children: [
        "url: ",
        blog.url
      ] }, void 0, true, {
        fileName: "/Users/saiadiraju/Library/CloudStorage/GoogleDrive-saiadi4002@gmail.com/My Drive/Programming/AppDev/Full Stack Open/bloglist-frontend/src/components/Blog.jsx",
        lineNumber: 49,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("p", { children: [
        "likes: ",
        likes,
        /* @__PURE__ */ jsxDEV("button", { onClick: () => likeBlog(), children: "like" }, void 0, false, {
          fileName: "/Users/saiadiraju/Library/CloudStorage/GoogleDrive-saiadi4002@gmail.com/My Drive/Programming/AppDev/Full Stack Open/bloglist-frontend/src/components/Blog.jsx",
          lineNumber: 50,
          columnNumber: 34
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/saiadiraju/Library/CloudStorage/GoogleDrive-saiadi4002@gmail.com/My Drive/Programming/AppDev/Full Stack Open/bloglist-frontend/src/components/Blog.jsx",
        lineNumber: 50,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("p", { children: [
        "user: ",
        blog.user ? blog.user.name : "not found"
      ] }, void 0, true, {
        fileName: "/Users/saiadiraju/Library/CloudStorage/GoogleDrive-saiadi4002@gmail.com/My Drive/Programming/AppDev/Full Stack Open/bloglist-frontend/src/components/Blog.jsx",
        lineNumber: 51,
        columnNumber: 17
      }, this),
      blog.user.id === user.id ? /* @__PURE__ */ jsxDEV("button", { onClick: () => deleteBlog(), children: "remove" }, void 0, false, {
        fileName: "/Users/saiadiraju/Library/CloudStorage/GoogleDrive-saiadi4002@gmail.com/My Drive/Programming/AppDev/Full Stack Open/bloglist-frontend/src/components/Blog.jsx",
        lineNumber: 52,
        columnNumber: 45
      }, this) : null
    ] }, void 0, true, {
      fileName: "/Users/saiadiraju/Library/CloudStorage/GoogleDrive-saiadi4002@gmail.com/My Drive/Programming/AppDev/Full Stack Open/bloglist-frontend/src/components/Blog.jsx",
      lineNumber: 48,
      columnNumber: 13
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/saiadiraju/Library/CloudStorage/GoogleDrive-saiadi4002@gmail.com/My Drive/Programming/AppDev/Full Stack Open/bloglist-frontend/src/components/Blog.jsx",
    lineNumber: 46,
    columnNumber: 10
  }, this);
};
_s(Blog, "oCuoEZHtOMeluAwn1dwq2Fb/F7s=");
_c = Blog;
export default Blog;
var _c;
$RefreshReg$(_c, "Blog");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/saiadiraju/Library/CloudStorage/GoogleDrive-saiadi4002@gmail.com/My Drive/Programming/AppDev/Full Stack Open/bloglist-frontend/src/components/Blog.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBc0MwQzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUF0QzFDLFNBQVNBLGdCQUFnQjtBQUN6QixPQUFPQyxpQkFBaUI7QUFFeEIsTUFBTUMsT0FBT0EsQ0FBQztBQUFBLEVBQUVDO0FBQUFBLEVBQU1DO0FBQUFBLEVBQU1DO0FBQUFBLEVBQWFDO0FBQUFBLEVBQVVDO0FBQUssTUFBTTtBQUFBQyxLQUFBO0FBQzFELFFBQU1DLFlBQVk7QUFBQSxJQUNkQyxPQUFPO0FBQUEsSUFDUEMsWUFBWTtBQUFBLElBQ1pDLGFBQWE7QUFBQSxJQUNiQyxRQUFRO0FBQUEsSUFDUkMsYUFBYTtBQUFBLElBQ2JDLGNBQWM7QUFBQSxFQUNsQjtBQUNBLFFBQU0sQ0FBQ0MsTUFBTUMsT0FBTyxJQUFJakIsU0FBUyxDQUFDO0FBQUEsSUFBRWtCLFNBQVM7QUFBQSxFQUFPLEdBQUcsTUFBTSxDQUFDO0FBRTlELFFBQU0sQ0FBQ0MsT0FBT0MsUUFBUSxJQUFJcEIsU0FBU0csS0FBS2dCLEtBQUs7QUFDN0MsUUFBTUUsbUJBQW1CQSxNQUFNO0FBQzNCLFFBQUlMLEtBQUssQ0FBQyxNQUFNLFFBQVE7QUFDcEJDLGNBQVEsQ0FBQyxDQUFDLEdBQUcsTUFBTSxDQUFDO0FBQUEsSUFDeEIsV0FBV0QsS0FBSyxDQUFDLE1BQU0sUUFBUTtBQUMzQkMsY0FBUSxDQUFDO0FBQUEsUUFBRUMsU0FBUztBQUFBLE1BQU8sR0FBRSxNQUFNLENBQUM7QUFBQSxJQUN4QztBQUFBLEVBQ0o7QUFDQSxRQUFNSSxXQUFXQSxNQUFNO0FBQ25CZixTQUFLSixNQUFNQyxJQUFJO0FBQ2ZnQixhQUFTRCxRQUFRLENBQUM7QUFBQSxFQUN0QjtBQUNBLFFBQU1JLGFBQWFBLE1BQU07QUFDckIsUUFBSTtBQUNBQyxhQUFPQyxRQUFRLGtEQUFrRCxJQUFJeEIsWUFBWXNCLFdBQVdwQixJQUFJLElBQUk7QUFDcEdFLGtCQUFZQyxTQUFTb0IsT0FBUUMsV0FBVUEsVUFBVXhCLElBQUssQ0FBQztBQUFBLElBRTNELFFBQVE7QUFDSnFCLGFBQU9JLE1BQU0sbURBQW1EO0FBQUEsSUFDcEU7QUFBQSxFQUNKO0FBRUEsU0FDSSx1QkFBQyxTQUFJLE9BQU9uQixXQUNSO0FBQUEsMkJBQUMsT0FBR047QUFBQUEsV0FBSzBCO0FBQUFBLE1BQU07QUFBQSxNQUFFMUIsS0FBSzJCO0FBQUFBLE1BQU87QUFBQSxNQUFDLHVCQUFDLFlBQU8sU0FBUyxNQUFNVCxpQkFBaUIsR0FBSUwsZUFBSyxDQUFDLEtBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBb0Q7QUFBQSxTQUFsRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTJGO0FBQUEsSUFDM0YsdUJBQUMsU0FBSSxPQUFPQSxLQUFLLENBQUMsR0FBRyxXQUFVLGFBQzNCO0FBQUEsNkJBQUMsT0FBRTtBQUFBO0FBQUEsUUFBTWIsS0FBSzRCO0FBQUFBLFdBQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFrQjtBQUFBLE1BQ2xCLHVCQUFDLE9BQUU7QUFBQTtBQUFBLFFBQVFaO0FBQUFBLFFBQU0sdUJBQUMsWUFBTyxTQUFTLE1BQU1HLFNBQVMsR0FBRyxvQkFBbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF1QztBQUFBLFdBQXhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBaUU7QUFBQSxNQUNqRSx1QkFBQyxPQUFFO0FBQUE7QUFBQSxRQUFPbkIsS0FBS0MsT0FBT0QsS0FBS0MsS0FBSzRCLE9BQU87QUFBQSxXQUF2QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW1EO0FBQUEsTUFDbEQ3QixLQUFLQyxLQUFLNkIsT0FBTzdCLEtBQUs2QixLQUFLLHVCQUFDLFlBQU8sU0FBUyxNQUFNVixXQUFXLEdBQUcsc0JBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBMkMsSUFBWTtBQUFBLFNBSnZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FLQTtBQUFBLE9BUEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQVFBO0FBRVI7QUFBQ2YsR0E1Q0tOLE1BQUk7QUFBQWdDLEtBQUpoQztBQThDTixlQUFlQTtBQUFJLElBQUFnQztBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJCbG9nU2VydmljZSIsIkJsb2ciLCJibG9nIiwidXNlciIsInNldEJsb2dMaXN0IiwiYmxvZ0xpc3QiLCJsaWtlIiwiX3MiLCJibG9nU3R5bGUiLCJjb2xvciIsInBhZGRpbmdUb3AiLCJwYWRkaW5nTGVmdCIsImJvcmRlciIsImJvcmRlcldpZHRoIiwibWFyZ2luQm90dG9tIiwiZGlzcCIsInNldERpc3AiLCJkaXNwbGF5IiwibGlrZXMiLCJzZXRMaWtlcyIsInRvZ2dsZVZpc2liaWxpdHkiLCJsaWtlQmxvZyIsImRlbGV0ZUJsb2ciLCJ3aW5kb3ciLCJjb25maXJtIiwiZmlsdGVyIiwiYmxvZzEiLCJhbGVydCIsInRpdGxlIiwiYXV0aG9yIiwidXJsIiwibmFtZSIsImlkIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJCbG9nLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IEJsb2dTZXJ2aWNlIGZyb20gJy4uL3NlcnZpY2VzL2Jsb2dzJ1xuXG5jb25zdCBCbG9nID0gKHsgYmxvZywgdXNlciwgc2V0QmxvZ0xpc3QsIGJsb2dMaXN0LCBsaWtlIH0pID0+IHtcbiAgICBjb25zdCBibG9nU3R5bGUgPSB7XG4gICAgICAgIGNvbG9yOiAnYmx1ZScsXG4gICAgICAgIHBhZGRpbmdUb3A6IDEwLFxuICAgICAgICBwYWRkaW5nTGVmdDogMixcbiAgICAgICAgYm9yZGVyOiAnc29saWQnLFxuICAgICAgICBib3JkZXJXaWR0aDogMSxcbiAgICAgICAgbWFyZ2luQm90dG9tOiA1XG4gICAgfVxuICAgIGNvbnN0IFtkaXNwLCBzZXREaXNwXSA9IHVzZVN0YXRlKFt7IGRpc3BsYXk6ICdub25lJyB9LCAnVmlldyddKVxuICAgIC8vIFN0YXRlIHVzZWQgdG8gaGFuZGxlIGxpa2VzIHNvIHRoYXQgdGhlIGNvbXBvbmVudCByZWxvYWRzIHdoZW4gdGhlIGxpa2UgYnV0dG9uIGlzIHByZXNzZWRcbiAgICBjb25zdCBbbGlrZXMsIHNldExpa2VzXSA9IHVzZVN0YXRlKGJsb2cubGlrZXMpXG4gICAgY29uc3QgdG9nZ2xlVmlzaWJpbGl0eSA9ICgpID0+IHtcbiAgICAgICAgaWYgKGRpc3BbMV0gPT09ICdWaWV3Jykge1xuICAgICAgICAgICAgc2V0RGlzcChbe30sICdIaWRlJ10pXG4gICAgICAgIH0gZWxzZSBpZiAoZGlzcFsxXSA9PT0gJ0hpZGUnKSB7XG4gICAgICAgICAgICBzZXREaXNwKFt7IGRpc3BsYXk6ICdub25lJyB9LCdWaWV3J10pXG4gICAgICAgIH1cbiAgICB9XG4gICAgY29uc3QgbGlrZUJsb2cgPSAoKSA9PiB7XG4gICAgICAgIGxpa2UoYmxvZywgdXNlcilcbiAgICAgICAgc2V0TGlrZXMobGlrZXMgKyAxKVxuICAgIH1cbiAgICBjb25zdCBkZWxldGVCbG9nID0gKCkgPT4ge1xuICAgICAgICB0cnkge1xuICAgICAgICAgICAgd2luZG93LmNvbmZpcm0oJ0FyZSB5b3Ugc3VyZSB5b3Ugd291bGQgbGlrZSB0byBkZWxldGUgdGhpcyBibG9nPycpID8gQmxvZ1NlcnZpY2UuZGVsZXRlQmxvZyhibG9nKSA6IG51bGxcbiAgICAgICAgICAgIHNldEJsb2dMaXN0KGJsb2dMaXN0LmZpbHRlcigoYmxvZzEpID0+IGJsb2cxICE9PSBibG9nLCkpXG5cbiAgICAgICAgfSBjYXRjaCB7XG4gICAgICAgICAgICB3aW5kb3cuYWxlcnQoJ0Vycm9yISBDYW5ub3QgZGVsZXRlIGJsb2csIHBsZWFzZSB0cnkgYWdhaW4gbGF0ZXInKVxuICAgICAgICB9XG4gICAgfVxuXG4gICAgcmV0dXJuIChcbiAgICAgICAgPGRpdiBzdHlsZT17YmxvZ1N0eWxlfT5cbiAgICAgICAgICAgIDxwPntibG9nLnRpdGxlfSB7YmxvZy5hdXRob3J9IDxidXR0b24gb25DbGljaz17KCkgPT4gdG9nZ2xlVmlzaWJpbGl0eSgpfT57ZGlzcFsxXX08L2J1dHRvbj48L3A+XG4gICAgICAgICAgICA8ZGl2IHN0eWxlPXtkaXNwWzBdfSBjbGFzc05hbWU9J3RvZ2dsZVZpcyc+XG4gICAgICAgICAgICAgICAgPHA+dXJsOiB7YmxvZy51cmx9PC9wPlxuICAgICAgICAgICAgICAgIDxwPmxpa2VzOiB7bGlrZXN9PGJ1dHRvbiBvbkNsaWNrPXsoKSA9PiBsaWtlQmxvZygpfT5saWtlPC9idXR0b24+PC9wPlxuICAgICAgICAgICAgICAgIDxwPnVzZXI6IHtibG9nLnVzZXIgPyBibG9nLnVzZXIubmFtZSA6ICdub3QgZm91bmQnfTwvcD5cbiAgICAgICAgICAgICAgICB7YmxvZy51c2VyLmlkID09PSB1c2VyLmlkID8gPGJ1dHRvbiBvbkNsaWNrPXsoKSA9PiBkZWxldGVCbG9nKCl9PnJlbW92ZTwvYnV0dG9uPiA6IG51bGx9XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgKVxufVxuXG5leHBvcnQgZGVmYXVsdCBCbG9nIl0sImZpbGUiOiIvVXNlcnMvc2FpYWRpcmFqdS9MaWJyYXJ5L0Nsb3VkU3RvcmFnZS9Hb29nbGVEcml2ZS1zYWlhZGk0MDAyQGdtYWlsLmNvbS9NeSBEcml2ZS9Qcm9ncmFtbWluZy9BcHBEZXYvRnVsbCBTdGFjayBPcGVuL2Jsb2dsaXN0LWZyb250ZW5kL3NyYy9jb21wb25lbnRzL0Jsb2cuanN4In0=